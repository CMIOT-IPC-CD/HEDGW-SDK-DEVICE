/*
 * 版    权: Copyright (c) 2019, CMIOT
 * 文 件 名: test_register_fun.h
 * 作    者: 黄博良(03901149)
 * 时    间: 2019.07.15
 * 功能描述: SDK 测试程序主函数
 * 其    它:
 * 修订历史:
 */

#ifndef __TEST_REGISTER_FUNS_H__
#define __TEST_REGISTER_FUNS_H__

extern int32_t test_register(void);

#endif
