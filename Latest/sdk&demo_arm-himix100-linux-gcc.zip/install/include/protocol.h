#ifndef __PROTOCOL_IPC_H__
#define __PROTOCOL_IPC_H__

#include <arpa/inet.h>
#include <netinet/in.h>

#include "types_ipc.h"
#include "errno_ipc.h"
#include "list_ipc.h"

#define PROT_DISABLE 0
#define PROT_ENABLE 1

enum prot_weekday
{
    PROT_WEEKDAY_SUN    = 0,
    PROT_WEEKDAY_MON    = 1,
    PROT_WEEKDAY_TUES   = 2,
    PROT_WEEKDAY_WED    = 3,
    PROT_WEEKDAY_THUR   = 4,
    PROT_WEEKDAY_FRI    = 5,
    PROT_WEEKDAY_SAT    = 6,
    PROT_WEEKDAY_CNT    = 7,
};

typedef struct prot_time
{
    int8_t wday;    /* 星期, 取值区间为[0,6]，其中0代表星期天，1代表星期一，以此类推 */
    int8_t hour;
    int8_t min;
    int8_t sec;
}prot_time_t;

typedef struct prot_time_period
{
    prot_time_t begin_time;
    prot_time_t end_time;
}prot_time_period_t;

/* 网络模块公用提前 */
#define PROT_ETH_NO_USE_FIX_MAC             0
#define PROT_ETH_USE_FIX_MAC                1

#define PROT_MAC_ADDR_LEN                   (6)         /* MAC地址长度 */

/***********************begin: 基本信息配置模块***************************************/
#define PROT_DEV_NAME_LEN_MAX               (31 + 1)
#define PROT_DEV_NO_LEN_MAX                 (31 + 1)
#define PROT_DEV_MODEL_NO_LEN_MAX           (31 + 1)
#define PROT_DEV_ID_LEN_MAX                 (31 + 1)
#define PROT_DEV_SN_LEN_MAX                 (31 + 1)
#define PROT_DEV_IMEI_LEN_MAX               (15 + 1)
#define PROT_DEV_SYSTEM_VER_LEN_MAX         (63 + 1)
#define PROT_DEV_LTE_FW_VER_LEN_MAX         (63 + 1)

typedef struct prot_dev_name_conf
{
    char        dev_name[PROT_DEV_NAME_LEN_MAX];
    uint32_t    dev_name_len;
}prot_dev_name_conf_t;

typedef struct prot_dev_no_conf
{
    char        dev_no[PROT_DEV_NO_LEN_MAX];
    uint32_t    dev_no_len;
}prot_dev_no_conf_t;

typedef struct prot_model_no_conf
{
    char        model_no[PROT_DEV_MODEL_NO_LEN_MAX];
    uint32_t    model_no_len;
}prot_model_no_conf_t;

typedef struct prot_dev_id_conf
{
    char        dev_id[PROT_DEV_ID_LEN_MAX];
    uint32_t    dev_id_len;
}prot_dev_id_conf_t;

typedef struct prot_fix_mac_conf
{
    uint16_t    use_fix_mac;
    uint8_t     fix_mac[PROT_MAC_ADDR_LEN];
}prot_fix_mac_conf_t;

typedef struct prot_dev_imei_conf
{
    char        dev_imei[PROT_DEV_IMEI_LEN_MAX];
    uint32_t    dev_imei_len;
}prot_dev_imei_conf_t;

typedef struct prot_dev_sn_conf
{
    char        dev_sn[PROT_DEV_SN_LEN_MAX];
    uint32_t    dev_sn_len;
}prot_dev_sn_conf_t;

typedef struct prot_system_ver_conf
{
    char        system_ver[PROT_DEV_SYSTEM_VER_LEN_MAX];
    uint32_t    system_ver_len;
}prot_system_ver_conf_t;

typedef struct prot_basic_info
{
    char        dev_name[PROT_DEV_NAME_LEN_MAX];
    uint32_t    dev_name_len;

    char        dev_no[PROT_DEV_NO_LEN_MAX];
    uint32_t    dev_no_len;

    char        model_no[PROT_DEV_MODEL_NO_LEN_MAX];
    uint32_t    model_no_len;

    char        dev_id[PROT_DEV_ID_LEN_MAX];
    uint32_t    dev_id_len;
    
    char        dev_imei[PROT_DEV_IMEI_LEN_MAX];
    uint32_t    dev_imei_len;
    
    char        dev_sn[PROT_DEV_SN_LEN_MAX];
    uint32_t    dev_sn_len;
    
    uint16_t    use_fix_mac;
    uint8_t     fix_mac[PROT_MAC_ADDR_LEN];
    uint32_t    fix_mac_len;
    
    char        system_ver[PROT_DEV_SYSTEM_VER_LEN_MAX];
    uint32_t    system_ver_len;

    char        lte_fw_ver[PROT_DEV_LTE_FW_VER_LEN_MAX];
    uint32_t    lte_fw_ver_len;
}prot_basic_info_t;

/***********************end: 基本信息配置模块***************************************/

/**************** begin: 网络模块(已经最终确定) **************************************/
/* begin: 网络公用 */
#define PROT_IFACE_NAME_LEN_MAX             (19 + 1)    /* 网卡名字的最大长度, 1预留给'\0' */

/* 网络类型定义 */
enum prot_network_type
{
    PROT_NETWORK_TYPE_INVALID       = 0,
    PROT_NETWORK_TYPE_ETH           = 1,        /* ETH 上网 */
    PROT_NETWORK_TYPE_LTE           = 2,        /* LTE 上网 */
    PROT_NETWORK_TYPE_WIFI          = 3,        /* WIFI 上网 */
    PROT_NETWORK_TYPE_CNT           = 4
};

enum prot_select_network_type
{
    PROT_SELECT_NETWORK_TYPE_ETH    = 1,        /* 选择ETH 上网 */
    PROT_SELECT_NETWORK_TYPE_LTE    = 2,        /* 选择LTE 上网 */
    PROT_SELECT_NETWORK_TYPE_WIFI   = 3,        /* 选择WIFI 上网 */
    PROT_SELECT_NETWORK_TYPE_AUTO   = 4,        
};

enum prot_network_state
{
    PROT_NETWORK_STATE_DISCONNECT   = 0,
    PROT_NETWORK_STATE_CONNECT      = 1,
};

enum prot_use_dhcp_type
{
    PROT_NO_USE_DHCP = 0,               /* 关掉DHCP */ 
    PROT_USE_DHCP    = 1                /* 打开DHCP */ 
};

enum prot_use_dns_type
{
    PROT_NO_USE_DNS_AUTO = 0,           /* 自动DNS */ 
    PROT_USE_DNS_AUTO    = 1            /* 手动DNS */ 
};

/* 设置业务网络配置的数据结构 */
typedef struct prot_service_network_conf
{
    int32_t select_network_type;        /* enum prot_select_network_type 定义 */
}prot_service_network_conf_t;

typedef struct prot_service_iface_info
{   
    BOOL        has_available_iface;                    
    uint32_t    network_type;                           /* 网络类型:eth, lte, wifi */
    char        iface_name[PROT_IFACE_NAME_LEN_MAX];    /* 对应的接口名 */
    uint16_t    iface_name_len;
}prot_service_iface_info_t;
/* end: 网络公用 */

/**************** end: 网络模块(已经最终确定) **************************************/

enum prot_video_resolution
{
    PROT_MAIN_STREAM_ID = 0,
    PROT_SUB_STREAM_ID = 1,
};
/*******************************begin: OSD ***************************/

#define PROT_OSD_TITLE_MAX_LEN              64

#define PROT_OSD_DISABLE               0
#define PROT_OSD_ENABLE                1

#define PROT_OSD_ATTR_ITEM_NOT_SET          (-1)

typedef enum
{
    PROT_OSD_LOCATION_TOP_LEFT      = 0,
    PROT_OSD_LOCATION_TOP_RIGHT,
    PROT_OSD_LOCATION_BOTTOM_LEFT,
    PROT_OSD_LOCATION_BOTTOM_RIGHT
}prot_osd_location_t;

typedef enum
{
    PROT_OSD_FONT_SIZE_SMALL = 0,
    PROT_OSD_FONT_SIZE_MIDDLE,
    PROT_OSD_FONT_SIZE_LARGE
}prot_osd_font_size_t;

typedef struct prot_osd_title_conf
{
    uint32_t    enable;
    int32_t     title_location;
    char        title[PROT_OSD_TITLE_MAX_LEN];
    uint32_t    title_len;
}prot_osd_title_conf_t;


typedef struct prot_osd_color
{
    int32_t red;            /* 0 ~ 255,  PROT_OSD_ATTR_ITEM_NOT_SET表示未设此值 */
    int32_t green;          /* 0 ~ 255,  PROT_OSD_ATTR_ITEM_NOT_SET表示未设此值 */
    int32_t blue;           /* 0 ~ 255,  PROT_OSD_ATTR_ITEM_NOT_SET表示未设此值 */
}prot_osd_color_t;


typedef struct prot_osd_attr_conf
{
    int32_t             transparency;   /* 0 ~ 100,  若未设, 赋值PROT_OSD_ATTR_ITEM_NOT_SET */
    int32_t             font_size;      /* 见prot_osd_font_size_t定义, 若未设, 赋值PROT_OSD_ATTR_ITEM_NOT_SET */
    prot_osd_color_t    font_color;     /* 若未设, 赋值PROT_OSD_ATTR_ITEM_NOT_SET */    
}prot_osd_attr_conf_t;

typedef struct prot_osd_para
{
    int32_t             title_enable;
    char                title[PROT_OSD_TITLE_MAX_LEN];
    int32_t             title_len;
    int32_t             title_location;       /* 见 prot_osd_location_t 定义 */

    int32_t             time_enable;

    int32_t             transparency;   /* 0 ~ 100 */
    int32_t             font_size;      /* 见 prot_osd_font_size_t 定义 */
    prot_osd_color_t    font_color;
}prot_osd_para_t;

/*******************************end: OSD ***************************/

/*******************************begin: COVER ***************************/

#define PROT_CVR_MAX_NUMS_AREA          5
#define PROT_CVR_ATTR_ITEM_NOT_SET      (-1)
#define PROT_CVR_DISABLE                0
#define PROT_CVR_ENABLE                 1

typedef struct prot_cvr_area_attr
{
    int32_t posx;                   /* 遮盖区域的左上水平位置 */
    int32_t posy;                   /* 遮盖区域的左上垂直位置 */
    int32_t width;                  /* 遮盖区域的图像宽度 */
    int32_t height;                 /* 遮盖区域的图像高度 */
}prot_cvr_area_attr_t;

typedef struct prot_cvr_para
{
    int32_t                     enable;                             /* 遮盖使能开关 */
    int32_t                     area_num;
    prot_cvr_area_attr_t        area[PROT_CVR_MAX_NUMS_AREA];       /* 遮盖区域信息 */
}prot_cvr_para_t;
/*******************************end: COVER ***************************/


/*******************************begin: VENC和IENC ***************************/
typedef enum
{
    PROT_CODE_TYPE_JPEG = 26,
    PROT_CODE_TYPE_H264 = 96,
    PROT_CODE_TYPE_H265 = 265
}prot_code_type_t;

enum
{
    PROT_IMAGE_QUALITY_LEVEL_HIGH       = 0,
    PROT_IMAGE_QUALITY_LEVEL_MODERATE   = 1,
    PROT_IMAGE_QUALITY_LEVEL_LOW        = 2,
    PROT_IMAGE_QUALITY_LEVEL_CNT        = 3
};

/* 与 PIC_SIZE_E 中的值相对应 */
enum
{
    PROT_RESOLUTION_HD1080              = 17,   /* 1920 * 1080 */
    PROT_RESOLUTION_HD720               = 16,   /* 1280 * 720 */
    PROT_RESOLUTION_WVGA                = 12,   /* 854 * 480 */
    PROT_RESOLUTION_VGA                 = 7,    /* 640 * 480 */
    PROT_RESOLUTION_CIF                 = 1     /* 352 * 288 */
};

/* begin: VENC模块相关数据结构 */
enum
{
    PROT_CBR_BITRATE = 0,
    PROT_VBR_BITRATE = 1
};

enum
{
    PROT_MAIN_VIDEO_STREAM      = 0,
    PROT_SUB_VIDEO_STREAM       = 1,
    PROT_VIDEO_STREAM_CNT       = 2
};

enum
{
    PROT_BITRATE_UPPER_LIMIT_256K       = 256,
    PROT_BITRATE_UPPER_LIMIT_512K       = 512,
    PROT_BITRATE_UPPER_LIMIT_1024K      = 1024,
    PROT_BITRATE_UPPER_LIMIT_2048K      = 2048,
    PROT_BITRATE_UPPER_LIMIT_3072K      = 3072,
    PROT_BITRATE_UPPER_LIMIT_4096K      = 4096,
    PROT_BITRATE_UPPER_LIMIT_6144K      = 6144,
    PROT_BITRATE_UPPER_LIMIT_8192K      = 8192
};

#define PROT_VENC_PARA_ITEM_NOT_SET     (-1)

typedef struct prot_venc_stream_para
{
    int32_t       resolution;            /* 码流分辨率    17 PIC_HD1080 16 PIC_HD720 12 PIC_WVGA 7 VGA 1 CIF */ 
    int32_t       bitrate_type;          /* 码率类型      0 定码率 1 变码率*/
    int32_t       frame_rate;            /* 码流视频帧率  5 10  15  20  25 */
    int32_t       bitrate_upper_limit;   /* 码流视频码率 */
    int32_t       image_quality_level;   /* 码流图像质量，仅变码率使用, 0 高 1 中 2 低 */
    int32_t       gop;                   /* 码流I帧间隔 */
    int32_t       code_type;             /* 码流编码类型  96 PT_H264   265 PT_H265 */
}prot_venc_stream_para_t;

#define PROT_CLOUD_SCHEDULE_NUM_MAX         70
#define PROT_CLOUD_SCHEDULE_NUM_DAY_MAX     10
#define PROT_NALU_MAX_CNT_OF_FRAME          (5)

typedef struct prot_nalu_info
{
    uint32_t type;              /* NALU类型, 由 VENC_DATA_TYPE_U 定义*/
    uint32_t offset;            /* 此NALU在数据buff中的偏移量, 即针对prot_frame_data_t中data的偏移量 */
    uint32_t len;               /* 此NALU的数据长度, 单位为字节 */
}prot_nalu_info_t;

#if 1   /* 修改时注意同步修改 */
typedef struct prot_frame_hdr
{
    struct ipc_list_head    list;
    uint64_t                pts;                                    /* 生成帧的时间 */
    uint32_t                code_type;                              /* 此帧编码类型 */
    uint32_t                fps;
    uint32_t                nalu_type;
    uint32_t                nalu_cnt;                               /* 1帧中含有NALU的数量, 不同的NALU的具体信息由nalu_info来表征 */            
    prot_nalu_info_t        nalu_info[PROT_NALU_MAX_CNT_OF_FRAME];  /* 表征帧中不同NALU的具体信息 */
    uint32_t                data_len;                               /* 此帧数据长度, 对于I帧包含SPS, PPS, SEI, Islice类型的数据, 对于P帧, 只包含Pslice */
}prot_frame_hdr_t;

typedef struct prot_frame_data
{
    struct ipc_list_head    list;
    uint64_t                pts;                                    /* 生成帧的时间 */
    uint32_t                code_type;                              /* 此帧编码类型 */
    uint32_t                fps;
    uint32_t                nalu_type;                              /* 这个nalu type类型是指携带的视频载荷, 不应该为SPS, PPS或者SEI */
    uint32_t                nalu_cnt;                               /* 1帧中含有NALU的数量, 不同的NALU的具体信息由nalu_info来表征 */            
    prot_nalu_info_t        nalu_info[PROT_NALU_MAX_CNT_OF_FRAME];  /* 表征帧中不同NALU的具体信息 */
    uint32_t                data_len;                               /* 此帧数据长度, 对于I帧包含SPS, PPS, SEI, Islice                                                                   类型的数据, 对于P帧, 只包含Pslice */
    uint8_t                 *data;                                  /* 1帧中的全部数据 */ 
}prot_frame_data_t;

typedef struct
{
    prot_frame_hdr_t hdr;
    uint8_t data[0];            /* 视频数据 */
}prot_frame_pkt_t;
#endif

/* end: VENC模块相关数据结构 */

/* begin: IENC模块相关数据结构 */
typedef struct prot_image_data_hdr
{
    struct ipc_list_head    list;
    uint64_t                pts;            /* 生成图片的时间 */
    uint32_t                code_type;      /* 图片编码格式, 目前只有JPEG一种编码格式 */
    uint32_t                data_len;       /* 图像长度 */
}prot_image_data_hdr_t;

typedef struct prot_image_data
{
    struct ipc_list_head    list;
    uint64_t                pts;            /* 生成图片的时间 */
    uint32_t                code_type;      /* 图片编码格式, 目前只有JPEG一种编码格式 */
    uint32_t                data_len;       /* 图像长度 */
    uint8_t                 data[0];        /* 图像数据 */
}prot_image_data_t;

typedef struct
{
    prot_image_data_hdr_t hdr;
    uint8_t* data;            /* 视频数据 */
}prot_image_pkt_t;

/* end: IENC模块相关数据结构 */
/*******************************end: VENC和IENC ***************************/



typedef struct prot_cloud_storage_info
{
    int32_t cloud_storage_enable;                               /* 云录像是否开启 */
    int32_t resolution;                                         /* 云录像分辨率 */
    int32_t video_time;                                         /* 云录像文件分段间隔, 单位分钟 */
    int32_t record_mode;                                        /* 云录像方式: 0 按时间段内上传; 1 按时间段内画面运动上传 */
    prot_time_period_t time_period[PROT_CLOUD_SCHEDULE_NUM_MAX];/* 云录像时间表 */
    int32_t time_num;                                           /* 云录像时间段个数 */
}prot_cloud_storage_info_t;

typedef struct prot_cloud_capture_info
{
    int32_t capture_enable;                                     /* 云存储抓拍是否开启 */
    int32_t resolution;                                         /* 云存储抓拍分辨率 */
    int32_t interval;                                           /* 云存储抓拍间隔, 单位秒 */
    prot_time_period_t time_period[PROT_CLOUD_SCHEDULE_NUM_MAX];/* 云存储抓拍时间表 */    
    int32_t time_num;                                           /* 云存储抓拍时间段个数 */
}prot_cloud_capture_info_t;

/**************** begin: IPS模块(已经最终确定)**************************************/
/* 对于图像属性参数, 若未设置, 需使用此值 */
#define PROT_IMAGE_ATTR_PARA_NOT_SET        (-1)

/* 时间时/分/秒,若未设置,需使用此值 */
#define PROT_TIME_PARA_NOT_SET              (-1)

/* 日夜参数切换方式 */
#define PROT_DAY_NIGHT_SWITCH_NOT_SET       (-1)
#define PROT_DAY_NIGHT_SWITCH_MANUAL        (1)
#define PROT_DAY_NIGHT_SWITCH_AUTO          (2)

/* 调节锐度的方式 */
#define PROT_ADJUST_SHARP_NOT_SET           (-1)
#define PROT_ADJUST_SHARP_MANUAL            (1)
#define PROT_ADJUST_SHARP_AUTO              (2)

/* 图像是否启用倒转 */
#define PROT_IMAGE_USE_FLIP_NOT_SET         (-1)
#define PROT_IMAGE_USE_NO_FLIP              (0)
#define PROT_IMAGE_USE_FLIP                 (1)

/* 图像是否启用镜像 */
#define PROT_IMAGE_USE_MIRROR_NOT_SET       (-1)
#define PROT_IMAGE_USE_NO_MIRROR            (0)
#define PROT_IMAGE_USE_MIRROR               (1)

/* 图像是否启用宽动态 */
#define PROT_IMAGE_USE_WDR_NOT_SET          (-1)
#define PROT_IMAGE_USE_NO_WDR               (0)
#define PROT_IMAGE_USE_WDR                  (1)

enum gamma_para_group
{
    PROT_GAMMA_PARA_GROUP_NOT_SET   = -1,
    PROT_GAMMA_PARA_GROUP_0         = 0,
    PROT_GAMMA_PARA_GROUP_1         = 1,
    PROT_GAMMA_PARA_GROUP_2         = 2,
    PROT_GAMMA_PARA_GROUP_3         = 3
};

/* 背光补偿校正类型枚举 */
enum blc_mode
{
    PROT_BLC_MODE_NOT_SET   = -1,
    PROT_BLC_MODE_OFF       = 0,
    PROT_BLC_MODE_LEFT      = 1,
    PROT_BLC_MODE_RIGHT     = 2,
    PROT_BLC_MODE_TOP       = 3,
    PROT_BLC_MODE_BOTTOM    = 4,
    PROT_BLC_MODE_CENTRE    = 5 
};


typedef struct prot_day_night_switch_conf
{
    int32_t         switch_type;
    prot_time_t     begin_time;
    prot_time_t     end_time;
}prot_day_night_switch_conf_t;

typedef struct prot_image_attr_para
{
    int8_t  lum;                /* 亮度,   0 ~ 100, PROT_IMAGE_ATTR_PARA_NOT_SET代表未设此值 */
    int8_t  hue;                /* 色调,   0 ~ 100, PROT_IMAGE_ATTR_PARA_NOT_SET代表未设此值 */
    int8_t  satu;               /* 饱和度, 0 ~ 100, PROT_IMAGE_ATTR_PARA_NOT_SET代表未设此值 */
    int8_t  contrast;           /* 对比度, 0 ~ 100, PROT_IMAGE_ATTR_PARA_NOT_SET代表未设此值 */
    int8_t  denoise;            /* 降噪,   0 ~ 100, PROT_IMAGE_ATTR_PARA_NOT_SET代表未设此值 */
    int8_t  adjust_sharp_type;  /* 调节锐度的方式 */
    int8_t  sharp;              /* 锐度值, 0 ~ 100, PROT_IMAGE_ATTR_PARA_NOT_SET代表未设此值 */
    int8_t  resv;
}prot_image_attr_para_t;

typedef struct prot_image_attr_conf
{
    prot_image_attr_para_t day_para;
    prot_image_attr_para_t night_para;
}prot_image_attr_conf_t;

typedef struct prot_image_state
{
    /* 当前日夜切换的参数状态 */
    int32_t                 switch_type;
    prot_time_t             begin_time;
    prot_time_t             end_time;

    /* 当前图像属性参数 */
    prot_image_attr_para_t  day_para;
    prot_image_attr_para_t  night_para;

    int8_t                  use_flip;
    int8_t                  use_mirror;
    int8_t                  use_wdr;
    int8_t                  gamma_para_group; 
    int8_t                  blc_mode;
    int8_t                  resv[3];
}prot_image_state_t;

typedef prot_image_state_t prot_image_display_para_t;

/******************** end: IPS模块(已经最终确定) **************************************/

/********************** begin: 侦测事件模块 ******************************/
#define PROT_MD_SCHEDULE_NUM_MAX 35
#define MAX_NUMS_AREA_MD 5

typedef struct prot_vda_area_attr
{
    int32_t posx;                   /* 侦测区域的左上水平位置 */
    int32_t posy;                   /* 侦测区域的左上垂直位置 */
    int32_t width;                  /* 侦测区域的图像宽度 */
    int32_t height;                 /* 侦测区域的图像高度 */
}prot_vda_area_attr_t;

typedef struct prot_vda_point_attr
{
    int32_t posx;
    int32_t posy;
}prot_vda_point_attr_t;

/* 图像尺寸定义 */
typedef struct prot_vda_detect_size
{
    int32_t posx;                   /* 侦测最大最小尺寸的左上水平位置 */
    int32_t posy;                   /* 侦测最大最小尺寸的左上垂直位置 */

    int32_t width;
    int32_t height;
}prot_vda_detect_size_t;

/* 移动侦测 */
#define PROT_MD_DISABLE_DETECT                  (0)
#define PROT_MD_ENABLE_DETECT                   (1)

#define PROT_MD_MAX_NUMS_AREA                   (5)
#define PROT_MD_TIME_PERIOD_MAX_CNT             (35)
#define PROT_MD_ITEM_NOT_SET                    (-1)

typedef struct prot_md_area_para
{
    int32_t                 sensitivity;                        /* 移动侦测灵敏度, 当为PROT_MD_ITEM_NOT_SET时,
                                                                   表示没有设置此值 */

    int32_t                 nums_md_area;                       /* 侦测区域数量, 当为PROT_MD_ITEM_NOT_SET时,
                                                                   表示没有设置区域 */
    prot_vda_area_attr_t    md_area[PROT_MD_MAX_NUMS_AREA];     /* 侦测发生移动的区域 */
}prot_md_area_para_t;

typedef struct prot_md_defense_time_para
{
    int32_t             time_period_cnt;                            /* 侦测时间段数量, 当为PROT_MD_ITEM_NOT_SET时,
                                                                       表示没有设置布防时间 */
    prot_time_period_t  time_period[PROT_MD_TIME_PERIOD_MAX_CNT];   /* 侦测时间段 */
}prot_md_defense_time_para_t;


/* 遮挡侦测(occlusion detect) */
#define PROT_OD_DISABLE_DETECT                  (0)
#define PROT_OD_ENABLE_DETECT                   (1)

#define PROT_OD_MAX_NUMS_AREA                   (5)
#define PROT_OD_TIME_PERIOD_MAX_CNT             (35)
#define PROT_OD_ITEM_NOT_SET                    (-1)

typedef struct prot_od_area_para
{
    int32_t                 sensitivity;                        /* 遮挡侦测灵敏度, 当为PROT_OD_ITEM_NOT_SET时,
                                                                   表示没有设置此值 */

    int32_t                 nums_od_area;                       /* 遮挡区域数量, 当为PROT_OD_ITEM_NOT_SET时,
                                                                   表示没有设置区域 */
    prot_vda_area_attr_t    od_area[PROT_OD_MAX_NUMS_AREA];     /* 侦测发生遮挡的区域 */
}prot_od_area_para_t;


typedef struct prot_od_defense_time_para
{
    int32_t             time_period_cnt;                            /* 侦测时间段数量, 当为PROT_OD_ITEM_NOT_SET时,
                                                                       表示没有设置时间段 */                            
    prot_time_period_t  time_period[PROT_OD_TIME_PERIOD_MAX_CNT];   /* 侦测时间段 */
}prot_od_defense_time_para_t;


/* 越界侦测(cross detect) */
#define PROT_CD_DISABLE_DETECT                  (0)
#define PROT_CD_ENABLE_DETECT                   (1)

#define PROT_CD_TIME_PERIOD_MAX_CNT             (35)
#define PROT_CD_ITEM_NOT_SET                    (-1)

enum prot_cross_direction_type
{
    PROT_CD_TWO_WAY_TYPE    = 0,
    PROT_CD_A_TO_B_TYPE     = 1,
    PROT_CD_B_TO_A_TYPE     = 2
};

typedef struct prot_cd_area_para
{

    int32_t                 sensitivity;            /* 越界侦测灵敏度, 当为PROT_CD_ITEM_NOT_SET时,
                                                       表示没有设置此值 */
    BOOL                    is_set_area;            /* 当为FALSE时, 下面参数无效, 表示没有设置区域, 采用原有值或默认值 */                                            
    int32_t                 is_set_arrow;           /* 用户是否设置了箭头 */
    int32_t                 is_set_minarea;         /* 用户是否设置了最小区域*/
    int32_t                 is_set_maxarea;         /* 用户是否设置了最大区域*/
    int32_t                 cross_direction;        /* 越界方向定义参见enum prot_cross_direction_type */
    prot_vda_point_attr_t   border_point1;          /* 越界线端点1 */
    prot_vda_point_attr_t   border_point2;          /* 越界线端点2 */
    prot_vda_point_attr_t   area_mark_a;            /* 界线区域A标识点 */
    prot_vda_point_attr_t   area_mark_b;            /* 界线区域B标识点 */
    prot_vda_detect_size_t  detect_min_size;        /* 越界侦测最小侦测尺寸 */   
    prot_vda_detect_size_t  detect_max_size;        /* 越界侦测最大侦测尺寸 */ 
}prot_cd_area_para_t;

typedef struct prot_cd_defense_time_para
{

    int32_t             time_period_cnt;                            /* 越界侦测时间段数量, 当为PROT_CD_ITEM_NOT_SET时,
                                                                       表示没有设置时间段 */ 
    prot_time_period_t  time_period[PROT_CD_TIME_PERIOD_MAX_CNT];   /* 侦测时间段 */
}prot_cd_defense_time_para_t;


/* 区域入侵检测(intrusion detect) */
#define PROT_ID_DISABLE_DETECT                  (0)
#define PROT_ID_ENABLE_DETECT                   (1)

#define PROT_ID_TIME_PERIOD_MAX_CNT             (35)
#define PROT_ID_ITEM_NOT_SET                    (-1)

typedef struct prot_id_area_para
{

    int32_t                 sensitivity;        /* 侦测灵敏度, 当为PROT_ID_ITEM_NOT_SET时, 表示没有设置此值 */
    int32_t                 time_thresh;        /* 入侵侦测时间阈值, 当为PROT_ID_ITEM_NOT_SET时, 表示没有设置此值 */

    BOOL                    is_set_area;        /* 当为FALSE时, 下面参数无效, 表示没有设置区域, 采用原有值或默认值 */
    int32_t                 is_set_detectarea;  /* 当为FALSE时, 说明没有设置检测区域*/
    int32_t                 is_set_minarea;     /* 当为FALSE时, 说明没有设置最小检测尺寸*/
    int32_t                 is_set_maxarea;     /* 当为FALSE时, 说明没有设置最小检测尺寸*/
    prot_vda_area_attr_t    detect_area;        /* 检测区域位置及大小 */
    prot_vda_detect_size_t  detect_min_size;    /* 入侵侦测最小侦测尺寸 */
    prot_vda_detect_size_t  detect_max_size;    /* 入侵侦测最大侦测尺寸 */
}prot_id_area_para_t;

typedef struct prot_id_defense_time_para
{

    int32_t             time_period_cnt;                            /* 入侵侦测时间段数量, 当为PROT_ID_ITEM_NOT_SET时,
                                                                       表示没有设置时间段 */ 
    prot_time_period_t  time_period[PROT_ID_TIME_PERIOD_MAX_CNT];   /* 侦测时间段 */
}prot_id_defense_time_para_t;

typedef enum prot_event_type
{
    PROT_EVENT_TYPE_INVALID = 0x00000000,
    PROT_EVENT_TYPE_MD      = 0x00000001,
    PROT_EVENT_TYPE_OD      = 0x00000002,
    PROT_EVENT_TYPE_CD      = 0x00000004,
    PROT_EVENT_TYPE_ID      = 0x00000008,
}prot_event_type_t;

/********************** end: 侦测事件模块 ******************************/


/*********************** begin: 时间模块 **************************************/
#define PROT_TIME_ZONE_STRING_LEN_MAX       16
#define PROT_TIME_ZONE_FIX_STRING_LEN_MAX   9
#define PROT_TIME_ZONE_CNT_MAX              27

#define PROT_DOMAIN_NAME_LEN_MAX            60

typedef enum prot_get_time_type
{
    PROT_GET_TIME_TYPE_NTP      = 1,
    PROT_GET_TIME_TYPE_MANUAL   = 2   
}prot_get_time_type_t;

typedef struct prot_time_zone_conf
{
    char        time_zone[PROT_TIME_ZONE_STRING_LEN_MAX];
    int32_t     time_zone_len;
}prot_time_zone_conf_t;

typedef struct prot_time_conf
{
    int32_t             get_time_type;

    union
    {
        struct
        {
            char        domain_name[PROT_DOMAIN_NAME_LEN_MAX];
            int16_t     domain_name_len;
            int16_t     port;
            int32_t     get_time_interval;
        }ntp;

        struct
        {
            int32_t     year;
            int32_t     mon;
            int32_t     mday;
            int32_t     hour;
            int32_t     min;
            int32_t     sec;
            uint8_t     resv[44];
        }time;            
    }u;
}prot_time_conf_t;

typedef struct prot_time_info
{
    char        time_zone[PROT_TIME_ZONE_STRING_LEN_MAX];
    int32_t     time_zone_len;

    int32_t     get_time_type;

    char        domain_name[PROT_DOMAIN_NAME_LEN_MAX];
    int16_t     domain_name_len;
    int16_t     port;
    int32_t     get_time_interval;

    int32_t     year;
    int32_t     mon;
    int32_t     day;
    int32_t     hour;
    int32_t     min;
    int32_t     sec; 
}prot_time_info_t;
/*********************** end: 时间模块 **************************************/

/*********************** begin: 选择平台配置*********************************/
enum prot_platform_type
{
    PROT_PLATFORM_TYPE_INVALID      = 0,
    PROT_PLATFORM_TYPE_HEDGW        = 1,
    PROT_PLATFORM_TYPE_GB28181      = 2,
    PROT_PLATFORM_TYPE_ONVIF        = 3,

    /* 本地WEB非平台, 但与其它平台处于同等地位, 因此也定义在这里 */
    PROT_PLATFORM_TYPE_LOCAL_WEB    = 4
};

/*********************** end: 选择平台配置*********************************/

/*********************** begin: hedgw 平台参数模块 **************************************/
#define PROT_PLATFORM_ADDR_LEN_MAX          (128)
#define PROT_INET_ADDR_STR_LEN              (16)
#define PROT_HEDGW_DEVICE_TOKEN_LEN_MAX     (36)
#define PROT_HEDGW_UNIFIED_ID_LEN_MAX       (36)
#define PROT_ACCESS_KEY_LEN_MAX             (36)
#define PROT_ACCESS_SECRET_LEN_MAX          (36)
#define PROT_COMMENT_LEN_MAX                (36)


#define PROT_OPENAPI_NOT_REGISTER           (0)
#define PROT_OPENAPI_REGISTER               (1)

#define PROT_HEDGW_ACCESS_STATE_DISCONNECT  (0)
#define PROT_HEDGW_ACCESS_STATE_CONNECT     (1)

#define PROT_HEDGW_PLATFORMY_TYPE_UNENCYPTED (0)
#define PROT_HEDGW_PLATFORMY_TYPE_ENCYPTED (1)

typedef struct prot_hedgw_platform_register_conf
{
    int32_t     reg_status;
    char        device_token[PROT_HEDGW_DEVICE_TOKEN_LEN_MAX];
    uint32_t    device_token_len;
    char        unified_id[PROT_HEDGW_UNIFIED_ID_LEN_MAX];
    uint32_t    unified_id_len;
    uint32_t    hedgw_platform_type;
}prot_hedgw_platform_register_conf_t;

typedef struct prot_hedgw_platform_info
{
    char        platform_addr[PROT_PLATFORM_ADDR_LEN_MAX];
    uint32_t    platform_addr_len;
    char        access_key[PROT_ACCESS_KEY_LEN_MAX];
    uint32_t    access_key_len;
    char        access_secret[PROT_ACCESS_SECRET_LEN_MAX];
    uint32_t     access_secret_len;
    char        comment[PROT_COMMENT_LEN_MAX];
    uint32_t    comment_len;
    int32_t     reg_status;
    char        device_token[PROT_HEDGW_DEVICE_TOKEN_LEN_MAX];
    uint32_t    device_token_len;
    char        unified_id[PROT_HEDGW_UNIFIED_ID_LEN_MAX];
    uint32_t    unified_id_len;
    uint32_t    hedgw_platform_type;
}prot_hedgw_platform_info_t;
/*********************** end: hedgw 平台参数模块 **************************************/

/* TODO: GB28181 */


/* TODO: ONVIF */

/*********************** begin: 升级模块 **************************************/
#define PROT_TMPFS_PATH_LEN_MAX                 (64)
#define PROT_LTE_OTA_MODULE_VERSION_LEN_MAX     (32)
#define PROT_LTE_OTA_FTP_SRV_IP_LEN_MAX         (32)
#define PROT_LTE_OTA_FTP_USER_NAME_LEN_MAX      (32)
#define PROT_LTE_OTA_FTP_USER_PASSWD_LEN_MAX    (32)
#define PROT_LTE_OTA_FILE_NAME_LEN_MAX          (64)
#define PROT_LTE_OTA_FTP_MD5_LEN_MAX            (36)

/* 升级状态定义 */
#define PROT_UPGRADE_STATE_NORMAL           (0)
#define PROT_UPGRADE_STATE_FAILED           (-1)
#define PROT_UPGRADE_STATE_FLASH_ERROR      (-2)
#define PROT_UPGRADE_STATE_SAME_FW_VER      (-3)
#define PROT_UPGRADE_STATE_CHECK_ERR        (-4)

/* 升级阶段定义 */
enum prot_upgrade_stage
{
    PROT_UPGRADE_STAGE_INIT         = 0,
    PROT_UPGRADE_STAGE_PREPARE      = 1,
    PROT_UPGRADE_STAGE_PROGRESS     = 2,
    PROT_UPGRADE_STAGE_FINISH       = 3 
};

typedef struct prot_upgrade_state
{
    int32_t state;
    int32_t stage;
    int32_t finish_percent;                 /* 0 ~ 100 */
}prot_upgrade_state_t;

typedef struct prot_upgrade_tmpfs_path
{
    char        tmpfs_path_image[PROT_TMPFS_PATH_LEN_MAX];              /* 镜像文件存储地址 */
    uint32_t    tmpfs_path_image_len;
    char        tmpfs_path_break[PROT_TMPFS_PATH_LEN_MAX];              /* 断点续传文件存储地址 */
    uint32_t    tmpfs_path_break_len;
}prot_upgrade_tmpfs_path_t;

typedef struct prot_ftp_upgrade_4g_module_para
{
    char ota_version_before[PROT_LTE_OTA_MODULE_VERSION_LEN_MAX];
    uint32_t ota_version_before_len;
    char ota_version_after[PROT_LTE_OTA_MODULE_VERSION_LEN_MAX];
    uint32_t ota_version_after_len;
    char ota_ftp_srv_ip[PROT_LTE_OTA_FTP_SRV_IP_LEN_MAX];
    uint32_t ota_ftp_srv_ip_len;
    uint16_t ota_ftp_srv_port;
    uint16_t reserved;
    char ota_ftp_user_name[PROT_LTE_OTA_FTP_USER_NAME_LEN_MAX];
    uint32_t ota_ftp_user_name_len;
    char ota_ftp_user_passwd[PROT_LTE_OTA_FTP_USER_PASSWD_LEN_MAX];
    uint32_t ota_ftp_user_passwd_len;
    char ota_file_name[PROT_LTE_OTA_FTP_USER_PASSWD_LEN_MAX];
    uint32_t ota_file_name_len;
    uint32_t model_type;
    char md5[PROT_LTE_OTA_FTP_MD5_LEN_MAX];
    uint32_t md5_len;
}prot_ftp_upgrade_4g_module_para_t;

/*********************** end: 升级模块 **************************************/

/*************************begin: 录制模块、抓拍模块的接口 ****************************/
enum prot_event_video_state
{
    PROT_EVENT_VIDEO_STATE_START        = 1,
    PROT_EVENT_VIDEO_STATE_PROGRESS     = 2,
    PROT_EVENT_VIDEO_STATE_END          = 3
};

typedef enum prot_trig_type
{
    PROT_TRIG_TYPE_TIMER    = 1,
    PROT_TRIG_TYPE_EVENT    = 2,
    PROT_TRIG_TYPE_ALL      = 3
}prot_trig_type_t;

/* Begin: 录制模块相关数据结构 */
#define PROT_RECORD_TIME_PERIOD_MAX_CNT  (35)
#define PROT_RECORD_ITEM_NOT_SET         (-1)

typedef struct prot_record_time_period
{
    int32_t     trig_type;                      /* 定时触发录制或事件触发录制 */
    prot_time_t begin_time;                     /* 录制时间段的起始时间 */
    prot_time_t end_time;                       /* 录制时间段的结束时间 */
}prot_record_time_period_t;

typedef struct prot_record_store_schedule
{
    BOOL                        enable_record;
    int32_t                     stream_type;            /* 录制计划中所选择的码流 */
    int32_t                     event_pre_record_time;  /* 事件触发的视频预录时间, 录制总时间为预录时间的2倍 */     

    int32_t                     time_period_cnt;        /* 实际录制时间段数量 */
    prot_record_time_period_t   time_period[PROT_RECORD_TIME_PERIOD_MAX_CNT];
}prot_record_store_schedule_t;
/* end: 录制模块相关数据结构 */


/* Begin: 抓拍模块相关数据结构 */
#define PROT_SNAP_TIME_PERIOD_MAX_CNT   (35)
#define PROT_SNAP_ITEM_NOT_SET          (-1)

typedef struct prot_snap_time_period
{
    int32_t     trig_type;                      /* 定时触发抓拍或事件触发抓拍 */
    prot_time_t begin_time;                     /* 抓拍时间段的起始时间 */
    prot_time_t end_time;                       /* 拍抓时间段的结束时间 */
}prot_snap_time_period_t;

typedef struct prot_snap_store_time
{
    BOOL                        enable_snap;
    int32_t                     time_period_cnt;        /* 实际存储时间段数量 */
    prot_snap_time_period_t     time_period[PROT_SNAP_TIME_PERIOD_MAX_CNT];
}prot_snap_store_time_t;

typedef struct prot_snap_store_para
{
    BOOL        enable_snap;
    int32_t     snap_time_interval;     /* 定时抓拍模式下的抓拍时间间隔 */
    int32_t     code_type;              /* 图片编码格式, 目前只有JPEG一种编码格式 */
    int32_t     resolution;             /* 图片分辨率    17 PIC_HD1080 16 PIC_HD720 12 PIC_WVGA 7 VGA 1 CIF */
    int32_t     image_quality_level;    /* 图片质量 */
}prot_snap_store_para_t;

/* end: 抓拍模块相关数据结构 */
/*************************end: 录制模块, 抓拍模块的接口 ****************************/

/*************************begin: 存储模块的接口 ****************************/
#define PROT_STOR_DWLD_FILE_DIR_LEN_MAX         128
#define PROT_STOR_DWLD_FILE_NAME_LEN_MAX        64

/* begin: 图片相关 */
typedef struct prot_stor_pic_query_req
{
    uint64_t pic_start_pts;
    uint64_t pic_end_pts;
    uint32_t trig_type;             /* 由 prot_trig_type_t 定义 */
    int32_t  event_type;            /* 由 prot_event_type_t 定义 */
    uint32_t start_resp_seq;        /* 返回响应开始序号, 该序号从1开始 */
    uint32_t end_resp_seq;          /* 返回响应结束序号, 注意改值为start_resp_seq + pic_num */
}prot_stor_pic_query_req_t;

typedef struct prot_stor_pic_query_node
{
    uint64_t pic_pts;
    uint32_t pic_id;
    uint32_t trig_type;             /* 由 prot_trig_type_t定义 */
    int32_t  event_type;            /* 由 prot_event_type_t 定义 */
    int32_t  pic_size;              /* 图片大小 */
}prot_stor_pic_query_node_t;

typedef struct prot_stor_pic_query_resp
{
    int32_t                     pic_total_cnt;  /* 满足条件总数 */
    int32_t                     pic_node_cnt;   /* 返回结果数 */
    prot_stor_pic_query_node_t  pic_node[0];    /* 返回查询结果内存空间，调用者需要根据需要返回结果条数开辟足够大小空间 */
}prot_stor_pic_query_resp_t;

typedef struct prot_stor_pic_dwld_node
{
    uint32_t pic_id;
}prot_stor_pic_dwld_node_t;

typedef struct prot_stor_pic_prepare_dwld_req
{
    int32_t                     dwld_cnt;
    prot_stor_pic_dwld_node_t   dwld_node[0];
}prot_stor_pic_prepare_dwld_req_t;

typedef struct prot_stor_pic_prepare_dwld_resp
{
    char file_dir[PROT_STOR_DWLD_FILE_DIR_LEN_MAX];
    char file_name[PROT_STOR_DWLD_FILE_NAME_LEN_MAX];
}prot_stor_pic_prepare_dwld_resp_t;

typedef struct prot_stor_pic_preview_req
{
    uint32_t pic_id;
}prot_stor_pic_preview_req_t;

typedef prot_stor_pic_prepare_dwld_resp_t prot_stor_pic_preview_resp_t;

/* end: 图片相关 */

/* begin: 视频相关 */
typedef enum
{
    PROT_STOR_QUERY_WEB_DOWNLOAD        = 1,
    PROT_STOR_QUERY_WEB_PLAYBACK        = 2,
    PROT_STOR_QUERY_PLATFORM_PLAYBACK   = 3
}prot_video_query_req_type_t;

typedef struct prot_stor_video_query_req
{
    uint64_t video_start_pts;
    uint64_t video_end_pts;
    uint32_t trig_type;             /* 由 prot_trig_type_t 定义 */
    int32_t  event_type;            /* 由 prot_event_type_t 定义 */
    uint8_t req_type;               /* 由 prot_video_query_req_type_t 定义 */
    uint8_t ret_all;                /* 是否将查询结果全部返回，TRUE，后面两个参数无效 */
    uint8_t reserved0[6];           /* 8字节对齐 */
    uint32_t start_resp_seq;        /* 返回响应开始序号, 该序号从1开始 */
    uint32_t end_resp_seq;          /* 返回响应结束序号, 注意改值为start_resp_seq + pic_num */
}prot_stor_video_query_req_t;

typedef enum
{
    VIDEO_FILE_SPLITED   = 1,                           /* 视频文件拆分存储 */
    VIDEO_FILE_UNSPLITED                                /* 视频文件结束 */
}prot_stor_video_split_flag_t;

typedef struct prot_stor_video_query_node
{    
    uint64_t video_start_pts;
    uint64_t video_end_pts;
    uint32_t video_id;
    uint32_t real_stor_id;
    uint32_t trig_type;             /* 由 prot_trig_type_t 定义 */
    int32_t  event_type;            /* 由 prot_event_type_t 定义 */
    uint32_t video_frame_rate;
    uint16_t video_stream_code_type;        /* 视频编码方式，H264、H265，同 PAYLOAD_TYPE_E */
    uint16_t video_stream_pic_size;         /* 视频分辨率，同 PIC_SIZE_E, 如果变更后，需要重新开辟文件存储 */
    uint8_t  video_file_split_flag;         /* 视频文件拆分标志，置 prot_stor_video_split_flag_t 后，表示此文件还有后续记录 */
    uint8_t reserve0[7];                    /* 8字节对齐 */
    uint32_t gop_interval;
    uint32_t gop_start_id;
    uint32_t gop_num;
    uint32_t size;
}prot_stor_video_query_node_t;

typedef struct prot_stor_video_resp
{
    int32_t video_total_cnt;  /* 满足条件总数 */
    int32_t video_node_cnt;   /* 返回结果数 */
    prot_stor_video_query_node_t  video_node[0];    /* 返回查询结果内存空间，调用者需要根据需要返回结果条数开辟足够大小空间 */
}prot_stor_video_resp_t;

typedef void (*prot_stor_video_resp_buf_free)(prot_stor_video_resp_t *free_buf);
typedef struct prot_stor_video_query_resp
{
    prot_stor_video_resp_t *video;
    BOOL is_need_alloc_buf;
    prot_stor_video_resp_buf_free buf_free;    
}prot_stor_video_query_resp_t;

typedef struct prot_stor_video_dwld_node
{
    uint32_t video_id;
}prot_stor_video_dwld_node_t;

typedef struct prot_stor_video_prepare_dwld_req
{
    int32_t                     dwld_cnt;
    prot_stor_video_dwld_node_t dwld_node[0];
}prot_stor_video_prepare_dwld_req_t;

typedef struct prot_stor_video_prepare_dwld_resp
{
    char file_dir[PROT_STOR_DWLD_FILE_DIR_LEN_MAX];
    char file_name[PROT_STOR_DWLD_FILE_NAME_LEN_MAX];
}prot_stor_video_prepare_dwld_resp_t;

typedef struct prot_stor_read_video_gop_req
{    
    uint32_t video_id;
    uint32_t gop_id;
}prot_stor_read_video_gop_req_t;

typedef void (*prot_stor_gop_buf_free)(uint8_t *free_buf);
typedef struct prot_stor_read_video_gop_resp
{   
    uint64_t gop_start_pts;         /* gop起始pts时间 */
    prot_stor_gop_buf_free buf_free;
    uint8_t *gop_data_addr;
    uint32_t gop_data_len;
    uint8_t *gop_parse_buf;
    uint32_t gop_proced_len;
    uint32_t frame_interval_pts;
    uint32_t storage_file_id;
    uint32_t video_id;
    uint32_t gop_id;
    uint8_t pframe_num;
    uint8_t frame_rate;
}prot_stor_read_video_gop_resp_t;


#define PROT_DISK_TYPE_SD_CARD          1

#define PROT_DISK_PARTIITION_MAX_LEN    (15 + 1)
#define PROT_DISK_VOLUME_MAX_LEN        (31 + 1)

#define PORT_DISK_FS_FAT32              1

#define PROT_DISK_STATUS_OK             1
#define PROT_DISK_STATUS_NOT_READY      2
#define PROT_DISK_STATUS_NOT_INSERT     3

typedef struct web_disk_query_info_resp
{
    int32_t disk_no;
    int32_t disk_type;
    char disk_partition[PROT_DISK_PARTIITION_MAX_LEN];
    char disk_volume[PROT_DISK_VOLUME_MAX_LEN];
    int32_t disk_fs;
    int32_t backup_flag;            /* 备份标志 0，已备份；1，未备份 */
    int32_t disk_total_size;        /* 单位: MB */
    int32_t disk_used_size;         /* 单位: MB */
    int32_t disk_free_size;         /* 单位: MB */
    int32_t disk_status;
    int32_t video_max_configurable_ratio;
    int32_t video_min_configurable_ratio;
    int32_t video_cur_ratio;
    int32_t video_total_size;
    int32_t video_stored_size;
    int32_t pic_total_size;
    int32_t pic_stored_size;
}prot_disk_query_info_resp_t;

typedef enum
{
    DISK_TYPE_NONE_EXIST    = 0,
    DISK_TYPE_SD_CARD       = 1,
    DISK_TYPE_HARD_DISK     = 2
}prot_disk_type_t;

typedef enum
{
    DISK_FS_UNKNOWN         = 0,
    DISK_FS_FAT32           = 1,
    DISK_FS_NTFS            = 2,
    DISK_FS_VFAT            = 3,
    DISK_FS_EXT2            = 4,
    DISK_FS_EXT4            = 5
}prot_disk_fs_t;

typedef struct
{
    prot_disk_type_t disk_type;
    prot_disk_fs_t disk_fs;
    char disk_partition[PROT_DISK_PARTIITION_MAX_LEN];
    char disk_volume[PROT_DISK_VOLUME_MAX_LEN];  
    int64_t disk_total_size;        /* 单位: Byte */
    int64_t disk_used_size;         /* 单位: Byte */
    int64_t disk_free_size;         /* 单位: Byte */
}prot_disk_info_t;

/* end: 视频相关 */

/*************************end: 存储模块的接口 ****************************/

/*************************begin: 回放模块接口 ****************************/

enum prot_playback_ctl_type
{
    PROT_PLAYBACK_CTL_STOP      = 0,
    PROT_PLAYBACK_CTL_PLAY      = 1,
    PROT_PLAYBACK_CTL_PAUSE     = 2,
    PROT_PLAYBACK_CTL_SPEED     = 3,
    PROT_PLAYBACK_CTL_DRAG      = 4,
    PROT_PLAYBACK_CTL_NULL      = 5
};

enum prot_playback_speed
{
    PROT_PLAYBACK_SPEED_X1        = 0,
    PROT_PLAYBACK_SPEED_X2        = 1,
    PROT_PLAYBACK_SPEED_X4        = 2,
    PROT_PLAYBACK_SPEED_X8        = 3,
    PROT_PLAYBACK_SPEED_HALF      = 4,
    PROT_PLAYBACK_SPEED_QUARTER   = 5,
    PROT_PLAYBACK_SPEED_EIGHTH    = 6
};

typedef struct prot_playback_time
{
    uint64_t start_time;
    uint64_t end_time;
}prot_playback_time_t;

typedef struct prot_playback_request
{
    int32_t platform_type;      /* enum prot_platform_type */
    int32_t play_speed;
    prot_playback_time_t time;
}prot_playback_request_t;

typedef struct prot_playback_ctl
{
    int32_t platform_type;      /* enum prot_platform_type */
    int32_t control_type;
    int32_t play_speed;
    uint64_t dragtime;
}prot_playback_ctl_t;

/*************************end: 回放模块接口 ****************************/

/*************************begin: ALARM模块接口 ****************************/

enum
{
    ALARM_MEDIA_TYPE_IMAGE  = 1,
    ALARM_MEDIA_TYPE_VIDEO  = 2
};

typedef struct prot_detect_event_alarm_para
{
    uint32_t alarm_interval_min;    /* 单位为秒 */
    uint32_t alarm_media_type;
}prot_detect_event_alarm_para_t;
/*************************end: ALARM模块接口 ****************************/

/*************************begin: 定位模块接口 ****************************/

typedef struct prot_location_para
{
    int32_t alarm_flag;     /* 报警标志位定义见JT/T808-2011表24 */
    int32_t status;         /* 状态位定义见JT/T808-2011表25,DWORD数据类型 */
    int32_t latitude;       /* 以度为单位的纬度值乘以10的6次方, 精确到百万分之一度 */
    int32_t longitude;      /* 以度为单位的经度值乘以10的6次方, 精确到百万分之一度 */
    int32_t height;         /* 海拔高度, 单位为米（m） */
    int32_t speed;          /* 1/10km/h, WORD数据类型 */
    int32_t direction;      /* 0-359,正北为0, 顺时针 */
    int32_t time;           /* 定位时间，Linux时间戳, 精确到秒, 时区 GMT+8 */
}prot_location_para_t;

/*************************end: 定位模块接口 ****************************/

/*************************begin: 日志模块接口 ****************************/

/* 上传日志时所使用的结构体 */
typedef struct prot_dlog_upload
{   
    char *file_buff;
    uint32_t file_buff_length;
    void (*dlog_free_upload_buffer) (char *dlog_upload_buf);   /* 用来释放file_buff的函数的指针*/
}prot_dlog_upload_t;

/*************************end: 日志模块接口 ****************************/

/*************************begin: 存储模块接口 ****************************/
typedef struct
{
    uint64_t start_pts;
    uint64_t end_pts;
}port_pts_node_t;

typedef struct
{
    int node_cnt;
    port_pts_node_t node[0];
}port_node_ctrl_t;

/**************************end: 存储模块接口 *****************************/
#endif

