/*
 * 版    权: Copyright (c) 2019, CMIOT .
 * 文 件 名: workqueue_ipc.h
 * 作    者: 贺鸿飞(03900475)
 * 时    间: 2019.03.01
 * 功能描述: 工作队列功能实现
 * 其    它:
 * 修订历史:
 */

#ifndef __WORKQUEUE_IPC_H__
#define __WORKQUEUE_IPC_H__

#include "types_ipc.h"
#include "list_ipc.h"

/* 各模块使用工作队列所用到的数据结构 */
typedef struct ipc_work_struct
{
    struct ipc_list_head list;
    void (*func)(void *data);       /* 需要工作队列代为执行的任务函数 */
    void *data;                     /* 工作队列代为执行的任务的私有数据, 由使用者定义具体的数据结构 */
}ipc_work_struct_t;


extern int32_t ipc_workqueue_module_init(void);
extern void ipc_init_work(ipc_work_struct_t *work, void (*func)(void *), void *data);
extern void ipc_schedule_work(ipc_work_struct_t *work);
#endif

