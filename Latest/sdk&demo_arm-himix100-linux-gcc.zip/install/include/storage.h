/* 
 * 版    权: Copyright (c) 2019, CMIOT .
 * 文 件 名: storage.h
 * 作    者: 
 * 时    间: 2019.05.06
 * 功能描述: SD存储对外接口头文件
 * 其    他: 
 * 修订历史: 
 */

#ifndef __STORAGE_H__
#define __STORAGE_H__

#include "types_ipc.h"
#include "protocol.h"
#include "list_ipc.h"

typedef struct
{
    int32_t (*sd_format)(void);
	int64_t (*sd_get_total_size)(void);
	int64_t (*sd_get_free_size)(void);
}stor_sd_ops_t;

typedef struct stor_video_attr
{    
    uint32_t trig_type;                 /* 由 prot_trig_type_t 定义 */
    int32_t event_type;                 /* 由 prot_event_type_t 定义 */
    uint16_t video_stream_code_type;    /* 视频编码方式，H264、H265，同 PAYLOAD_TYPE_E, TODO: video_stream_code_type */
    uint16_t video_stream_pic_size;     /* 视频分辨率，同 PIC_SIZE_E, 如果变更后，需要重新开辟文件存储 */
    uint8_t frame_rate;                 /* 视频帧率 */
    uint8_t iframe_interval;
}stor_video_attr_t;

typedef void (*stor_h264_free_frame)(prot_frame_pkt_t *free_frame);
typedef struct
{
    struct ipc_list_head list;
    stor_h264_free_frame free_frame;
    int frame_cnt;
}stor_ps_gop_to_h264_frame_t;

extern int32_t stor_video_open(stor_video_attr_t *attr);
extern int32_t stor_video_close(int32_t fd);

extern int32_t stor_write_video(int32_t fd, const prot_frame_data_t *frame);

extern int32_t stor_write_image(uint32_t trig_type, int32_t event_type, prot_image_pkt_t *image);
extern int32_t stor_query_image(prot_stor_pic_query_req_t *pic_query_info, prot_stor_pic_query_resp_t *query_resp);
/* 图片停止时建议调用，否者可能存在图片丢失 */
extern int32_t stor_image_flush(void);
extern int32_t stor_ps_gop_to_h264(prot_stor_read_video_gop_resp_t *gop, stor_ps_gop_to_h264_frame_t *h264_frame);
extern int32_t stor_query_video(prot_stor_video_query_req_t *video_query_info, prot_stor_video_query_resp_t *video_query_resp);
extern int32_t stor_video_read_gop(prot_stor_read_video_gop_req_t *gop_info, prot_stor_read_video_gop_resp_t *read_gop_resp);

extern int32_t stor_prepare_dwld_image(prot_stor_pic_prepare_dwld_req_t *download_info, prot_stor_pic_prepare_dwld_resp_t *download_resp);

extern int32_t stor_lib_task_create(stor_sd_ops_t *ops);
extern int32_t stor_lib_task_destroy(void);

#endif

