/*
 * 版    权: Copyright (c) 2019, CMIOT
 * 文 件 名: test_register_fun.h
 * 作    者: 黄博良(03901149)
 * 时    间: 2019.07.15
 * 功能描述: SDK 测试程序主函数
 * 其    它:
 * 修订历史:
 */

#include <string.h>
#include "minIni.h"
#include "types_ipc.h"
#include "errno_ipc.h"
#include "protocol.h"
#include "log.h"
#include "hedgw.h"

#define TEST_CONFIG_PATH "./conf_test.ini"
#define INI_MAX_VALUE_LEN 128

static prot_service_iface_info_t gs_iface_info = 
{
    .has_available_iface = TRUE,
    .network_type = PROT_NETWORK_TYPE_ETH,
    .iface_name = "enp2s0f0",
    .iface_name_len = 9
};

static int32_t gs_network_status;

static int32_t gs_live_stream_type = 0;

static int32_t get_service_iface_info(prot_service_iface_info_t *iface_info)
{
    memcpy(iface_info, &gs_iface_info, sizeof(prot_service_iface_info_t));
    return IPC_SUCCESS;
}

static int32_t notice_hedgw_network_status(int32_t status)
{
    gs_network_status = status;
    return IPC_SUCCESS;
}

static int32_t config_ini_gets(const char *section, const char *key, char *def_value, 
                                    char *data, uint32_t *data_len, int32_t data_len_max)
{
    char buf[INI_MAX_VALUE_LEN] = {0};
    
    ini_gets(section, key, def_value, buf, INI_MAX_VALUE_LEN, TEST_CONFIG_PATH);

    *data_len = strlen(buf) + 1;
    if (*data_len <= data_len_max)
    {
        strncpy(data, buf, data_len_max);
    }
    else
    {
        DBG_LOG(LOG_ERR, "get platform_addr err!");
    }

    if (strcmp(buf, def_value) == 0)
    {
        ini_puts(section, key, def_value, TEST_CONFIG_PATH);
    }

    return IPC_SUCCESS;
}
                                    
static int32_t get_platform_info(prot_hedgw_platform_info_t *platform_info)
{
    char section[INI_MAX_VALUE_LEN] = {0};
    char y_n_buf[2];
    uint32_t y_n_buf_len;

    snprintf(section, INI_MAX_VALUE_LEN, "platform_info");

    config_ini_gets(section, "platform_addr", "null", 
                    platform_info->platform_addr, &platform_info->platform_addr_len, PROT_PLATFORM_ADDR_LEN_MAX);

    config_ini_gets(section, "access_key", "null", 
                    platform_info->access_key, &platform_info->access_key_len, PROT_ACCESS_KEY_LEN_MAX);

    config_ini_gets(section, "access_secret", "null", 
                    platform_info->access_secret, &platform_info->access_secret_len, PROT_ACCESS_SECRET_LEN_MAX);

    config_ini_gets(section, "comment", "null", 
                    platform_info->comment, &platform_info->comment_len, PROT_COMMENT_LEN_MAX);

    config_ini_gets(section, "reg_status", "N", y_n_buf, &y_n_buf_len, 2);

    if (y_n_buf[0] ==  'Y')
    {
        platform_info->reg_status = PROT_OPENAPI_REGISTER;
    }
    else
    {
        platform_info->reg_status = PROT_OPENAPI_NOT_REGISTER;
    }
    
    config_ini_gets(section, "device_token", "null", 
                    platform_info->device_token, &platform_info->device_token_len, PROT_HEDGW_DEVICE_TOKEN_LEN_MAX);

    config_ini_gets(section, "unified_id", "null", 
                    platform_info->unified_id, &platform_info->unified_id_len, PROT_HEDGW_UNIFIED_ID_LEN_MAX);

    platform_info->hedgw_platform_type = ini_getl(section, "hedgw_platform_type", 1, TEST_CONFIG_PATH);
    
    return IPC_SUCCESS;
}

static int32_t set_platform_register_conf(prot_hedgw_platform_register_conf_t *platform_register_conf)
{
    char key[INI_MAX_VALUE_LEN] = {0};
    char section[INI_MAX_VALUE_LEN] = {0};

    snprintf(section, INI_MAX_VALUE_LEN, "platform_info");

    snprintf(key, INI_MAX_VALUE_LEN, "reg_status");
    if (platform_register_conf->reg_status == PROT_OPENAPI_REGISTER)
    {
        ini_puts(section, key, "Y", TEST_CONFIG_PATH);
    }
    else
    {
        ini_puts(section, key, "N", TEST_CONFIG_PATH);
    }

    snprintf(key, INI_MAX_VALUE_LEN, "device_token");
    ini_puts(section, key, platform_register_conf->device_token, TEST_CONFIG_PATH);
    
    snprintf(key, INI_MAX_VALUE_LEN, "unified_id");
    ini_puts(section, key, platform_register_conf->unified_id, TEST_CONFIG_PATH);

    snprintf(key, INI_MAX_VALUE_LEN, "hedgw_platform_type");
    ini_putl(section, key, platform_register_conf->hedgw_platform_type, TEST_CONFIG_PATH);
    
    return IPC_SUCCESS;
}

static int32_t get_basic_info(prot_basic_info_t *basic_info)
{
    char section[INI_MAX_VALUE_LEN] = {0};
    
    snprintf(section, INI_MAX_VALUE_LEN, "basic_info");
    
    config_ini_gets(section, "dev_name", "null", 
                    basic_info->dev_name, &basic_info->dev_name_len, PROT_DEV_NAME_LEN_MAX);

    config_ini_gets(section, "dev_no", "null", 
                    basic_info->dev_no, &basic_info->dev_no_len, PROT_DEV_NO_LEN_MAX);
    
    config_ini_gets(section, "model_no", "null", 
                    basic_info->model_no, &basic_info->model_no_len, PROT_DEV_MODEL_NO_LEN_MAX);
    
    config_ini_gets(section, "dev_id", "null", 
                    basic_info->dev_id, &basic_info->dev_id_len, PROT_DEV_ID_LEN_MAX);
    
    config_ini_gets(section, "dev_imei", "null", 
                    basic_info->dev_imei, &basic_info->dev_imei_len, PROT_DEV_IMEI_LEN_MAX);
    
    config_ini_gets(section, "dev_sn", "null", 
                    basic_info->dev_sn, &basic_info->dev_sn_len, PROT_DEV_SN_LEN_MAX);

    basic_info->use_fix_mac = ini_getl(section, "use_fix_mac", 0, TEST_CONFIG_PATH);
    
    config_ini_gets(section, "fix_mac", "null", 
                    (char *)basic_info->fix_mac, &basic_info->fix_mac_len, PROT_MAC_ADDR_LEN);

    config_ini_gets(section, "system_ver", "null", 
                    basic_info->system_ver, &basic_info->system_ver_len, PROT_DEV_SYSTEM_VER_LEN_MAX);

    config_ini_gets(section, "lte_fw_ver", "null", 
                    basic_info->lte_fw_ver, &basic_info->lte_fw_ver_len, PROT_DEV_LTE_FW_VER_LEN_MAX);
    
    return IPC_SUCCESS;
}

static int32_t set_live_stream_type(int32_t stream_type)
{
    gs_live_stream_type = stream_type;
    return IPC_SUCCESS;
}

static int32_t get_live_stream_type(int32_t *stream_type)
{
    *stream_type = gs_live_stream_type;
    return IPC_SUCCESS;
}

int32_t test_register(void)
{
    hedgw_network_ops_t network_ops;
    hedgw_platform_conf_ops_t platform_conf_ops;
    hedgw_basic_info_ops_t basic_info_ops;
    hedgw_mpp_ops_t mpp_ops = {0};
    
    network_ops.get_service_iface_info = get_service_iface_info;
    network_ops.notice_hedgw_network_status = notice_hedgw_network_status;
    hedgw_network_ops_register(&network_ops);

    platform_conf_ops.get_platform_info = get_platform_info;
    platform_conf_ops.set_platform_register_conf = set_platform_register_conf;
    hedgw_platform_conf_ops_register(&platform_conf_ops);

    basic_info_ops.get_basic_info = get_basic_info;
    hedgw_basic_info_ops_register(&basic_info_ops);

    mpp_ops.set_live_stream_type = set_live_stream_type;
    mpp_ops.get_live_stream_type = get_live_stream_type;
    hedgw_mpp_ops_register(&mpp_ops);
    
    return IPC_SUCCESS;
}

