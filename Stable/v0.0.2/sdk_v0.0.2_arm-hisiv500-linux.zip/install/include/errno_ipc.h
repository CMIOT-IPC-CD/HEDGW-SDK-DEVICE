#ifndef __ERROR_H__
#define __ERROR_H__

/* 通用错误码 */
#define IPC_SUCCESS      (0)
#define IPC_FAILED       (-1)
#define IPC_EINVAL       (-2)       /* 参数违法 */
#define IPC_ENOMEM       (-3)       /* 内存不足 */
#define IPC_ETIMEOUT     (-4)       /* 超时 */
#define IPC_EPERM        (-5)       /* 操作不被允许 */
#define IPC_EAGAIN       (-6)       /* 重试错误码 */
/* socket相关错误码 */
#define IPC_ESOCKET      (-7)       /* socket通信失败 */

/* 文件相关错误码 */
#define IPC_EIO          (-8)       /* io读写失败 */
#define IPC_ENOSPC       (-9)       /* 空间不足 */
#define IPC_EROFS        (-10)      /* 文件系统写保护 */

/* 视频相关错误码 */
#define IPC_ENOGOP       (-11)      /* 没有完整的GOP视频帧组 */
#define IPC_ESLICE       (-12)      /* 帧类型解析出错 */

/* 其它 */
#define IPC_ECRC         (-13)      /* CRC校验错误 */
#define IPC_NOEXIST      (-14)

/* sd卡存储相关 */
#define IPC_SD_NOT_READY    (-15)      /* SD卡未准备好 */
#define IPC_SD_NOT_EXIST    (-16)      /* SD卡不存在 */
#define IPC_SD_RW_ERROR     (-17)      /* SD卡读写错误 */
#define IPC_SD_FORMAT_ERROR (-18)      /* SD卡格式化错误 */
#define IPC_SD_BUSY         (-19)      /* SD卡忙 */

/* at指令相关 */
#define IPC_AT_EXEC_ERROR       (-20)
#define IPC_AT_EXEC_TIMEOUT     (-21)

#endif