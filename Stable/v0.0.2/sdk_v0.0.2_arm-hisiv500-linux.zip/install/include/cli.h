/* 
 * 版    权: Copyright (c) 2019, CMIOT .
 * 文 件 名: cli.h
 * 作    者: 贺鸿飞 (03900475)
 * 时    间: 2019.02.20
 * 功能描述: 对外接口头文件
 * 其    他: 
 * 修订历史: 
 */
 
#ifndef __CLI_H__
#define __CLI_H__

#include <stdarg.h> 

#include "list_ipc.h"

#define PARA_LEN_MAX                (32)            /* CLI命令行中的命令参数(字符串)的最大长度 */
#define MODULE_NAME_LEN_MAX         PARA_LEN_MAX    /* CLI命令行中模块名(字符串)的最大长度 */
#define CMD_NAME_LEN_MAX            PARA_LEN_MAX    /* CLI命令行中命令(字符串)的最大长度 */
#define PARA_CNT_MAX                (10)            /* CLI命令行中命令所带参数的最大个数 */           

/* CLI命令信息, 需要使用CLI功能的模块自己填充实现 */
typedef struct cli_cmd_info
{
    char cmd_name[CMD_NAME_LEN_MAX];
    void (*cmd_exec)(char *para[], uint16_t para_cnt);
    char *help_info;
}cli_cmd_info_t;

/* 其它模块向CLI模块注册CLI功能所用到的结构体 */
typedef struct cli_reg_info
{
    struct ipc_list_head list;
    char module_name[MODULE_NAME_LEN_MAX];
    uint16_t cmd_cnt;
    cli_cmd_info_t *cmd_info;
}cli_reg_info_t;

/* 执行CLI命令时, 所用到的打印宏, 此宏会把打印信息传输到agent端*/
#define CLI_PRINT(fmt, ...) cli_print("\r\n" fmt "\r\n", ##__VA_ARGS__)

extern int32_t cli_module_init(void);
extern int32_t cli_register(cli_reg_info_t *reg_info_new);
extern int32_t cli_unregister(cli_reg_info_t *reg_info_old);
extern void cli_print(const char *fmt, ...);

#endif

