/*
 * 版    权: Copyright (c) 2019, CMIOT
 * 文 件 名: list_ipc.h
 * 作    者: 贺鸿飞(03900475)
 * 时    间: 2019.02.25
 * 功能描述: 4G摄像机项目工程专用list头文件
 * 其    它:
 * 修订历史:
 */

#ifndef __LIST_IPC_H__
#define __LIST_IPC_H__

#include "types_ipc.h"

#define ipc_list_entry(ptr, type, member)   \
	((type *)((char *)(ptr)-(unsigned long)(&((type *)0)->member)))

#define ipc_container_of(ptr, type, member) \
    ((type *)((char *)(ptr)-(unsigned long)(&((type *)0)->member)))


struct ipc_list_head
{
	struct ipc_list_head *next;
	struct ipc_list_head *prev;
};

/*
 * ipc_list_first_entry - get the first element from a list
 * @ptr:	the list head to take the element from.
 * @type:	the type of the struct this is embedded in.
 * @member:	the name of the list_struct within the struct.
 *
 * Note, that list is expected to be not empty.
 */

#define ipc_list_first_entry(ptr, type, member) \
	ipc_list_entry((ptr)->next, type, member)

/*
 * ipc_list_first_entry_or_null - get the first element from a list
 * @ptr:	the list head to take the element from.
 * @type:	the type of the struct this is embedded in.
 * @member:	the name of the list_struct within the struct.
 *
 * Note that if the list is empty, it returns NULL.
 */
#define ipc_list_first_entry_or_null(ptr, type, member) \
	(!ipc_list_empty(ptr) ? ipc_list_first_entry(ptr, type, member) : NULL)

/*
 * ipc_list_for_each	-	iterate over a list
 * @pos:	the &struct list_head to use as a loop cursor.
 * @head:	the head for your list.
 */
#define ipc_list_for_each(pos, head) \
	for (pos = (head)->next; pos != (head); pos = pos->next)

/*
 * __ipc_list_for_each	-	iterate over a list
 * @pos:	the &struct list_head to use as a loop cursor.
 * @head:	the head for your list.
 *
 * This variant doesn't differ from list_for_each() any more.
 * We don't do prefetching in either case.
 */
#define __ipc_list_for_each(pos, head) \
	for (pos = (head)->next; pos != (head); pos = pos->next)

/*
 * ipc_list_for_each_prev	-	iterate over a list backwards
 * @pos:	the &struct list_head to use as a loop cursor.
 * @head:	the head for your list.
 */
#define ipc_list_for_each_prev(pos, head) \
	for (pos = (head)->prev; pos != (head); pos = pos->prev)

/*
 * list_for_each_safe - iterate over a list safe against removal of list entry
 * @pos:	the &struct list_head to use as a loop cursor.
 * @n:		another &struct list_head to use as temporary storage
 * @head:	the head for your list.
 */
#define ipc_list_for_each_safe(pos, n, head)                    \
    for (pos = (head)->next, n = pos->next;                     \
         pos != (head);                                         \
         pos = n, n = pos->next)

/*
 * ipc_list_for_each_prev_safe - iterate over a list backwards safe against removal of list entry
 * @pos:	the &struct list_head to use as a loop cursor.
 * @n:		another &struct list_head to use as temporary storage
 * @head:	the head for your list.
 */
#define ipc_list_for_each_prev_safe(pos, n, head)               \
	for (pos = (head)->prev, n = pos->prev;                     \
	     pos != (head);                                         \
	     pos = n, n = pos->prev)

/*
 * ipc_list_for_each_entry	-	iterate over list of given type
 * @pos:	the type * to use as a loop cursor.
 * @head:	the head for your list.
 * @member:	the name of the list_struct within the struct.
 */
#define ipc_list_for_each_entry(pos, head, type, member)	    \
	for (pos = ipc_list_entry((head)->next, type, member);	    \
	     &pos->member != (head); 	                            \
	     pos = ipc_list_entry(pos->member.next, type, member))


/*
 * ipc_list_for_each_entry_safe - iterate over list of given type safe against removal of list entry
 * @pos:	the type * to use as a loop cursor.
 * @n:		another type * to use as temporary storage
 * @head:	the head for your list.
 * @member:	the name of the list_struct within the struct.
 */
#define ipc_list_for_each_entry_safe(pos, n, head, type, member)                                                \
	for (pos = ipc_list_entry((head)->next, type, member), n = ipc_list_entry(pos->member.next, type, member);  \
	     &pos->member != (head); 					                                                            \
	     pos = n, n = ipc_list_entry(n->member.next, type, member))


extern void ipc_init_list_head(struct ipc_list_head *list);
extern void ipc_list_add(struct ipc_list_head *new_list, struct ipc_list_head *head);
extern void ipc_list_add_tail(struct ipc_list_head *new_list, struct ipc_list_head *head);
extern void ipc_list_del(struct ipc_list_head *entry);
extern void ipc_list_del_init(struct ipc_list_head *entry);
extern void ipc_list_move(struct ipc_list_head *list, struct ipc_list_head *head);
extern void ipc_list_move_tail(struct ipc_list_head *list, struct ipc_list_head *head);
extern void ipc_list_splice(struct ipc_list_head *list, struct ipc_list_head *head);
extern void ipc_list_splice_init(struct ipc_list_head *list, struct ipc_list_head *head);
extern void ipc_list_splice_tail(struct ipc_list_head *list, struct ipc_list_head *head);
extern void ipc_list_splice_tail_init(struct ipc_list_head *list, struct ipc_list_head *head);
extern int32_t ipc_list_is_last(const struct ipc_list_head *list, const struct ipc_list_head *head);
extern int32_t ipc_list_empty(const struct ipc_list_head *head);
#endif

