/*
 * 版    权: Copyright (c) 2019, CMIOT .
 * 文 件 名: log.h
 * 作    者: 贺鸿飞(03900475)
 * 时    间: 2019.03.01
 * 功能描述: 调试日志和运行日志头文件
 * 其    它: 
 * 修订历史:
 */

#ifndef __IPC_LOG_H__
#define __IPC_LOG_H__

#include <unistd.h>
#include <stdio.h>
#include <stdarg.h> 
#include <time.h>

#include "types_ipc.h"
#include "errno_ipc.h"

/* 调试日志的打印宏 */
#define DBG_LOG(level, fmt, ...) dlog_print(level, fmt " [%s][%d]\r\n", ##__VA_ARGS__, __FUNCTION__, __LINE__)

/* TODO: 运行时日志的打印宏 */
#define RUN_LOG(level, fmt, ...)

/* 日志打印级别定义, 调试日志和运行时日志共用 */
enum log_level
{
    LOG_ERR         = 0,
    LOG_WARNING,
    LOG_INFO,
    LOG_DEBUG,
    LOG_LEVEL_COUNT
};

extern int32_t log_module_init(const char* path);
extern void dlog_print(const int32_t level, const char *fmt, ...);
extern void dlog_dmesg(void);
extern void dlog_sync(void);

#endif

