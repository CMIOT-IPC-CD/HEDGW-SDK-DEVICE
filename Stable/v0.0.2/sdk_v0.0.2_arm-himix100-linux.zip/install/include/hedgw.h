/*
 * 版    权: Copyright (c) 2019, CMIOT
 * 文 件 名: hedgw.h
 * 作    者: 黄博良(03901149)
 * 时    间: 2019.02.25
 * 功能描述: 4G 摄像机和目私有协议头文件
 * 其    它:
 * 修订历史:
 */

#ifndef __HEDGW_H__
#define __HEDGW_H__

#include "protocol.h"

/************************** begin: 网络模块接口 ***********************/
typedef struct hedgw_network_ops
{
    int32_t (*get_service_iface_info)(prot_service_iface_info_t *iface_info);          /* 查询可用业务网络接口 */
    int32_t (*notice_hedgw_network_status)(int32_t status);                            /* 通知网络不可用 */
    int32_t (*hedwg_lte_ota_platfrom_intf)(prot_ftp_upgrade_4g_module_para_t *lte_ota_param);
}hedgw_network_ops_t;

extern int32_t hedgw_network_ops_register(hedgw_network_ops_t *ops);
/************************** end: 网络模块接口 ***************************/

/************************** begin: 平台参数设置接口 ***************************/
typedef struct hedgw_platform_conf_ops
{
    int32_t (*get_platform_info)(prot_hedgw_platform_info_t *platform_info);
    int32_t (*set_platform_register_conf)(prot_hedgw_platform_register_conf_t *platform_register_conf);
}hedgw_platform_conf_ops_t;

typedef struct hedgw_basic_info_ops
{
    int32_t (*get_basic_info)(prot_basic_info_t *basic_info);
}hedgw_basic_info_ops_t;

extern int32_t hedgw_basic_info_ops_register(hedgw_basic_info_ops_t *ops);
extern int32_t hedgw_platform_conf_ops_register(hedgw_platform_conf_ops_t *ops);
extern int32_t hedgw_get_access_state(void);
extern void hedgw_notice_platform_addr_changed(void);
/************************** end: 平台参数设置接口 ***************************/

/************************** begin: MPP模块接口 ***************************/
typedef struct hedgw_mpp_ops
{
    int32_t (*set_live_stream_type)(int32_t stream_type);
    int32_t (*get_live_stream_type)(int32_t *stream_type);
    
    int32_t (*set_cloud_stream_type)(int32_t stream_type);
    int32_t (*get_cloud_stream_type)(int32_t *stream_type);
    
    /* OSD */
    int32_t (*set_osd_conf)(const prot_osd_para_t *osd_para);
    int32_t (*get_osd_conf)(prot_osd_para_t *osd_para);

    /* VENC */
    int32_t (*set_venc_conf)(int32_t stream_type, const prot_venc_stream_para_t *stream_para);
    int32_t (*get_venc_conf)(int32_t stream_type, prot_venc_stream_para_t *stream_para);

    /* 图像显示参数(IPS) */
    int32_t (*set_image_display_para)(const prot_image_display_para_t *display_para);
    int32_t (*get_image_display_para)(prot_image_display_para_t *display_para);

    /* 移动侦测 */
    int32_t (*set_md_enable_para)(BOOL enable);
    BOOL    (*get_md_enable_para)(void);
    int32_t (*set_md_area_para)(const prot_md_area_para_t *area_para);
    int32_t (*get_md_area_para)(prot_md_area_para_t *area_para);
    int32_t (*set_md_defense_time_para)(const prot_md_defense_time_para_t *time_para);
    int32_t (*get_md_defense_time_para)(prot_md_defense_time_para_t *time_para);
    
    /* 越界侦测 */
    int32_t (*set_cd_enable_para)(BOOL enable);
    BOOL    (*get_cd_enable_para)(void);
    int32_t (*set_cd_area_para)(const prot_cd_area_para_t *area_para);
    int32_t (*get_cd_area_para)(prot_cd_area_para_t *area_para);
    int32_t (*set_cd_defense_time_para)(const prot_cd_defense_time_para_t *time_para);
    int32_t (*get_cd_defense_time_para)(prot_cd_defense_time_para_t *time_para);
    
    /* 入侵侦测 */
    int32_t (*set_id_enable_para)(BOOL enable);
    BOOL    (*get_id_enable_para)(void);
    int32_t (*set_id_area_para)(const prot_id_area_para_t *area_para);
    int32_t (*get_id_area_para)(prot_id_area_para_t *area_para);
    int32_t (*set_id_defense_time_para)(const prot_id_defense_time_para_t *time_para);
    int32_t (*get_id_defense_time_para)(prot_id_defense_time_para_t *time_para);
    
    int32_t (*snap_picture)(prot_image_data_t **picture);
    int32_t (*free_snap_picture)(prot_image_data_t **picture);
}hedgw_mpp_ops_t;

extern int32_t hedgw_mpp_ops_register(hedgw_mpp_ops_t *ops);
/************************** end: MPP模块接口 ***************************/

/********************* begin: 云存储流和直播流推送接口 ******************/

extern int32_t hedgw_send_live_data(int32_t chn_id, prot_frame_data_t *frame_data);
extern int32_t hedgw_send_live_audio_data(prot_audio_frame_data_t *audio_frame);
extern int32_t hedgw_send_cloud_data(int32_t chn_id, prot_frame_data_t *frame_data);
extern int32_t hedgw_send_cloud_audio_data(prot_audio_frame_data_t *audio_frame);
/********************* end: 云存储流和直播流推送接口 ********************/

/************************** begin: PLAYBACK模块接口 ***************************/
typedef struct hedgw_playback_ops
{
    int32_t (*hedgw_stor_query_video)(prot_stor_video_query_req_t *video_query_info, 
                                        prot_stor_video_query_resp_t *video_query_resp);
    int32_t (*hedgw_playback_request_fun)(prot_playback_request_t *playback_request);
    int32_t (*hedgw_playback_control_fun)(prot_playback_ctl_t *playback_ctl);
}hedgw_playback_ops_t;

extern int32_t hedgw_playback_ops_register(hedgw_playback_ops_t *ops);

extern int32_t hedgw_playback_setup(void);
extern int32_t hedgw_playback_stop(void);
extern int32_t hedgw_playback_push_stream(prot_frame_pkt_t *frame_data, uint32_t rtp_time_stamp);
/************************** end: PLAYBACK模块接口 ***************************/

/************************** begin: 事件告警模块接口 ***************************/
typedef struct hedgw_event_info
{
    uint64_t event_time;
    uint32_t event_type;
}hedgw_event_info_t;

typedef struct hedgw_alarm_ops
{
    int32_t (*set_detect_event_alarm_para)(uint32_t event_type, prot_detect_event_alarm_para_t *alarm_para);
    int32_t (*get_detect_event_alarm_para)(uint32_t event_type, prot_detect_event_alarm_para_t *alarm_para);
}hedgw_alarm_ops_t;

extern int32_t hedgw_alarm_ops_register(hedgw_alarm_ops_t *ops);

/* image_data和event_info只有在state为 PROT_EVENT_VIDEO_STATE_START 状态时才有效, 其它时候传NULL */
extern int32_t hedgw_send_event_video_data(uint32_t state, prot_frame_data_t *frame_data,
                                           prot_image_data_t *image_data, hedgw_event_info_t *event_info);

extern int32_t set_alarm_mp4_file_path(char *path, uint32_t path_len);

extern int32_t hedgw_send_event_image_data(prot_image_data_t *image_data, hedgw_event_info_t *event_info);
                                           
extern void hedgw_cloud_detect_event_notice(uint32_t event_type);

/************************** end: 事件告警模块接口 ***************************/

/************************** begin: 位置上传接口 ***************************/
extern int32_t hedgw_location_upload(prot_location_para_t *location_para);
/************************** end: 位置上传接口 ***************************/

/*************************begin: hedgw 平台校时 ****************************/
typedef struct hedgw_set_time_ops
{
    int32_t (*hedgw_set_time)(uint64_t time);       /* ms */
}hedgw_set_time_ops_t;

extern int32_t hedgw_set_time_ops_register(hedgw_set_time_ops_t *ops);
extern int32_t hedgw_get_hedgw_platform_time(void);

/*************************end: hedgw 平台校时 ****************************/

/******************** begin: 设备管理 *********************************/
typedef struct hedgw_dev_mgmt_ops
{
    int32_t (*reset_device)(void);
    BOOL    (*is_reseting)(void);
    int32_t (*hedgw_get_sd_info)(prot_disk_info_t *query_resp);
    int32_t (*hedgw_format_sd)(void);
}hedgw_dev_mgmt_ops_t;
extern int32_t hedgw_dev_mgmt_ops_register(hedgw_dev_mgmt_ops_t *ops);
/******************** end: 设备管理 *********************************/

/*************************begin: 日志上传 ****************************/
#define DLOG_UPLOAD_INIT    0   /* 主动上传 */
#define DLOG_UPLOAD_REQ     1   /* 请求上传 */

typedef struct hedgw_debug_log_ops
{
    int32_t (*hedgw_dlog_upload_read)(prot_dlog_upload_t *dlog_upload_info);
    int32_t (*hedgw_dlog_upload_success_confirm)(int32_t identification);
}hedgw_debug_log_ops_t;

extern int32_t hedgw_debug_log_ops_register(hedgw_debug_log_ops_t *ops);

int32_t hedgw_upload_log(int32_t log_trans_reason, char *data, uint32_t data_len);
/*************************end: 日志上传 ****************************/

/************************** begin: 升级设置接口 ***************************/
typedef struct hedgw_upgrade_ops
{
    /* 基本信息模块 */
    int32_t (*upgrade_prepare)(uint32_t platform_type);
    int32_t (*upgrade_get_path)(prot_upgrade_tmpfs_path_t *tmpfs_path);
    int32_t (*upgrade_start)(void);
    int32_t (*upgrade_take_fw_effect)(void);
}hedgw_upgrade_ops_t;

extern int32_t hedgw_upgrade_ops_register(hedgw_upgrade_ops_t *ops);
extern void hedgw_notice_upgrade_state(prot_upgrade_state_t *upgrade_state);
/************************** end: 升级设置接口 ***************************/

extern int32_t hedgw_init(void);

/* stream_buf_size：缓存buf开辟大小，用于缓存视频帧和音频帧，建议按照1个GOP组的音视频缓存BUF大小设置
 * nodes:缓存buf可存储多少个数据帧(含音频帧和数据帧)，建议按照1个GOP组的数量进行设置
 */
extern int32_t hedgw_start(int stream_buf_size, int nodes);
extern int32_t hedgw_exit(void);

#endif

