/*
 * 版    权: Copyright (c) 2019, CMIOT .
 * 文 件 名: timer_ipc.h
 * 作    者: 邓斌(03902439)
 * 时    间: 2019.03.01
 * 功能描述: 定时器功能实现的头文件
 * 其    它: 
 * 修订历史:
 */

#ifndef __IPC_TIMER_H__
#define __IPC_TIMER_H__

#include "types_ipc.h"
#include "list_ipc.h"
#include "workqueue_ipc.h"
#include "time_ipc.h"

/* 定时器使用者不能直接访问此结构体 */
typedef struct ipc_timer_list
{
    struct ipc_list_head list;
    uint32_t expires;                       /* 超时时间(相对于定时器启动时的时间, 单位为100ms, 即表示有多少个100ms) */
    uint32_t elapse;                        /* 定时器启动后, 逝去的时间, 单位为100ms, 即表示过去了多少个100ms */
    BOOL repeat;                            /* TRUE, 重复执行; FALSE, 只执行一次 */
    ipc_work_struct_t work;                 /* 定时器超时任务处理放在工作队列执行 */
}ipc_timer_list_t;

/* 判断是否到达日历时间的定时器 */
typedef struct ipc_cal_timer_list
{
    struct ipc_list_head list;
    ipc_tm_t cal_time;                      /* 超时的日历时间 */
    int32_t compare_offset;                 /* 用于超时比较的距离0点的偏移量, 单位为秒 */
    ipc_work_struct_t work;                 /* 定时器超时任务处理放在工作队列执行 */
}ipc_cal_timer_list_t;

extern int32_t ipc_timer_module_init(void);

/* 在使用定时器时, 必须先使用此函数进行初始化 */
extern void ipc_init_timer(ipc_timer_list_t *timer, void (*function)(void *data), void *data);

/* 1次填加, 可支持只执行1次, 也可支持重复执行 */
extern void ipc_add_timer(ipc_timer_list_t *timer, uint32_t expires, BOOL repeat);

/* 若timer还未超时, 删除, 若timer已经超时, 什么也不做 */
extern void ipc_del_timer(ipc_timer_list_t *timer);

/* 修改超时时间 */
extern void ipc_mod_timer(ipc_timer_list_t *timer, uint32_t expires);
#endif

