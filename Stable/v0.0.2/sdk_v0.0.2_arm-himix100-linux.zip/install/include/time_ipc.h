/*
 * 版    权: Copyright (c) 2019, CMIOT .
 * 文 件 名: time_ipc.h
 * 作    者: 贺鸿飞(03900475)
 * 时    间: 2019.03.01
 * 功能描述: 实现与时间相关的基础功能
 * 其    它:
 * 修订历史:
 */

#ifndef __TIME_IPC__
#define __TIME_IPC__

#include "types_ipc.h"
#include "protocol.h"

#define IPC_JIFFIES         ipc_get_jiffies()

#define IPC_DIFF_JIFFIES(a, b)          (a > b) ? (0xFFFFFFFFFFFFFFFF - b + a + 1) : (b - a)
/* 日历时间 */
typedef struct ipc_tm
{
    int32_t tm_sec;         /* 秒 – 取值区间为[0,59] */
    int32_t tm_min;         /* 分 - 取值区间为[0,59] */
    int32_t tm_hour;        /* 时 - 取值区间为[0,23] */
    int32_t tm_mday;        /* 一个月中的日期, 取值区间为[1,31] */
    int32_t tm_mon;         /* 月份, 从一月开始, 取值区间为[1,12], 不用加1处理 */
    int32_t tm_year;        /* 年份, 真实年份, 不用加1900处理*/
    int32_t tm_wday;        /* 星期, 取值区间为[0,6]，其中0代表星期天，1代表星期一，以此类推 */
}ipc_tm_t;

extern int32_t ipc_get_time(ipc_tm_t *tm_now);
extern int32_t ipc_convert_utc_to_time(uint64_t pts, ipc_tm_t *tm);
extern int32_t ipc_convert_time_to_utc(ipc_tm_t *tm, uint64_t *pts);
extern void ipc_get_utc_time_str(char *time_str, int max_len);
extern uint64_t ipc_get_jiffies(void);
extern void ipc_sleep(uint32_t seconds);
extern void ipc_msleep(uint32_t millisecond);
extern int32_t ipc_time_module_init(void);
extern void ipc_time_module_exit(void);

#endif

