#ifndef __TYPES_IPC_H__
#define __TYPES_IPC_H__

#include <stdint.h>

#define ARRAY_SIZE(x)   (sizeof(x) / sizeof(x[0]))

typedef enum
{
    FALSE = 0,
    TRUE  = 1
}BOOL;

#endif

