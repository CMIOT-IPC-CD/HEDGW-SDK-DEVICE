/*
 * 版    权: Copyright (c) 2019, CMIOT
 * 文 件 名: test_main.c
 * 作    者: 黄博良(03901149)
 * 时    间: 2019.07.15
 * 功能描述: SDK 测试程序主函数
 * 其    它:
 * 修订历史:
 */

#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>

#include "types_ipc.h"
#include "errno_ipc.h"
#include "time_ipc.h"
#include "log.h"
#include "cli.h"
#include "timer_ipc.h"
#include "test_register_funs.h"
#include "hedgw.h"

/*the nalu type of H264E*/
typedef enum hi_h264_nalu_type
{
     H264E_NALU_BSLICE = 0,                         /*B SLICE types*/    
     H264E_NALU_PSLICE = 1,                         /*P SLICE types*/
     H264E_NALU_ISLICE = 2,                         /*I SLICE types*/    
     H264E_NALU_IDRSLICE = 5,                       /*IDR SLICE types*/
     H264E_NALU_SEI    = 6,                         /*SEI types*/
     H264E_NALU_SPS    = 7,                         /*SPS types*/
     H264E_NALU_PPS    = 8,                         /*PPS types*/
     H264E_NALU_BUTT        
} hi_h264_nalu_type_t;

/*the nalu type of H265E*/
typedef enum hi_h265_nalu_type
{
     H265E_NALU_BSLICE = 0,                          /*B SLICE types*/
     H265E_NALU_PSLICE = 1,                          /*P SLICE types*/
     H265E_NALU_ISLICE = 2,                          /*I SLICE types*/    
     H265E_NALU_IDRSLICE = 19,                       /*IDR SLICE types*/
     H265E_NALU_VPS    = 32,                         /*VPS types*/
     H265E_NALU_SPS    = 33,                         /*SPS types*/
     H265E_NALU_PPS    = 34,                         /*PPS types*/
     H265E_NALU_SEI    = 39,                         /*SEI types*/
     
     H265E_NALU_BUTT        
} hi_h265_nalu_type_t;

int32_t gs_save_h264_fd;
static uint64_t gs_playback_start_time = 0;

static int find_start_code(uint8_t *buf)  
{  
    if(buf[0]!=0 || buf[1]!=0 || buf[2] !=0 || buf[3] !=1) 
        return 0;
    else 
        return 1;  
} 

static int32_t send_h264_frame_data(uint8_t *h264_frame_data_buf, int32_t nalu_len, int32_t nalu_type)
{
    int32_t j;
    int32_t start_code_found;
    int32_t offset = 0;
    int32_t len = 0;
    prot_frame_data_t frame_data;
    uint64_t gs_pts = 0LL;
    struct  timeval  tv;

    gettimeofday(&tv, NULL);
    gs_pts = (uint64_t)tv.tv_sec * 1000000ULL + (uint64_t)tv.tv_usec;
    if (nalu_type == H264E_NALU_IDRSLICE)
    {
        frame_data.code_type = PROT_CODE_TYPE_H264;
        frame_data.data = h264_frame_data_buf;
        frame_data.data_len = nalu_len;
        frame_data.fps = 25;
        frame_data.nalu_cnt = 4;
        frame_data.nalu_type= H264E_NALU_IDRSLICE;
        frame_data.pts = gs_pts;

        offset = 0;
		for(j = 0; j < 4; j++)
		{
			start_code_found = 0;
			while(!start_code_found)
			{
				if(nalu_len <= offset)
				{
					offset = nalu_len;
					break;
				}
				else
				{
					if(1 == find_start_code(h264_frame_data_buf + offset))
					{
						start_code_found = 1;
                        break;
					}
                    offset++;
                    len++;
				}
			}
            
            if (j == 0)
            {
                frame_data.nalu_info[0].offset = offset;
                frame_data.nalu_info[0].type = H264E_NALU_SPS;
            }
            else if (j == 1)
            {
                frame_data.nalu_info[j - 1].len = len;
                frame_data.nalu_info[j].type = H264E_NALU_PPS;
                frame_data.nalu_info[j].offset = offset;
            }
            else if (j == 2)
            {
                frame_data.nalu_info[j - 1].len = len;
                frame_data.nalu_info[j].type = H264E_NALU_SEI;
                frame_data.nalu_info[j].offset = offset;
            }
            else if (j == 3)
            {
                frame_data.nalu_info[j - 1].len = len;
                frame_data.nalu_info[j].type = H264E_NALU_SEI;
                frame_data.nalu_info[j].offset = offset;
                frame_data.nalu_info[j].len = nalu_len - offset;
            }
            
            offset++;
            len = 1;
		}
    }
    else
    {
        frame_data.code_type = PROT_CODE_TYPE_H264;
        frame_data.data = h264_frame_data_buf;
        frame_data.data_len = nalu_len;
        frame_data.fps = 25;
        frame_data.nalu_cnt = 1;
        frame_data.nalu_info[0].len = nalu_len;
        frame_data.nalu_info[0].offset = 0;
        frame_data.nalu_info[0].type = H264E_NALU_PSLICE;
        frame_data.nalu_type= nalu_type;
        frame_data.pts = gs_pts;
    }
    
    hedgw_send_live_data(0, &frame_data);
    return IPC_SUCCESS;
}

static int32_t live_delay(uint32_t video_push_cnt, uint32_t frame_rate, int32_t speed)
{
    uint64_t push_time;
    uint64_t now_time;
    uint32_t play_speed_weight;

    switch (speed)
    {
    case PROT_PLAYBACK_SPEED_HALF:
        play_speed_weight = 2;
        break;
    case PROT_PLAYBACK_SPEED_QUARTER:
        play_speed_weight = 4;
        break;
    default:
        play_speed_weight = 1;
        break;
    }
    
    push_time = gs_playback_start_time + video_push_cnt * 1000 * play_speed_weight / frame_rate;
    now_time = ipc_get_jiffies();
    if (push_time > now_time)
    {
        ipc_msleep((uint32_t)(push_time - now_time));
    }
    
    return IPC_SUCCESS;
}

int main(void)
{
    int32_t h264data_fd = -1;
    int32_t nalu_len;
    int32_t nalu_type;
    int32_t read_len;
    char nale_head[64];
    uint8_t *h264_frame_data_buf = NULL;
    int32_t curr_pos;
    uint32_t video_push_cnt = 0;
    int stream_buf_size;
    
    test_register();
    hedgw_init();
    
    stream_buf_size = 512 * 1024;
    hedgw_start(stream_buf_size, 40);

    while(hedgw_get_access_state() != PROT_HEDGW_ACCESS_STATE_CONNECT)
    {
        DBG_LOG(LOG_INFO, "wait platform access!");
        ipc_sleep(1);
    }
    
    h264_frame_data_buf = malloc(300 * 1024);
    if (h264_frame_data_buf == NULL)
    {
        DBG_LOG(LOG_ERR, "malloc for h264_frame_data_buf err");
    }
    h264data_fd = open("h264.dat", O_RDONLY);
    if (h264data_fd < 0)
    {
        DBG_LOG(LOG_ERR, "open h264.dat err");
    }
    
    curr_pos = lseek(h264data_fd, 0, SEEK_SET);
    if (curr_pos != 0)
    {
        DBG_LOG(LOG_ERR, "lseek err");
    }
    
    gs_playback_start_time = ipc_get_jiffies();
    
    while(1)
    {
        if (h264_frame_data_buf != NULL)
        {
            /* 读取数据私有头部 */
            read_len = read(h264data_fd, nale_head, 64);
            if (read_len == 0)
            {
                curr_pos = lseek(h264data_fd, 0, SEEK_SET);
                if (curr_pos != 0)
                {
                    DBG_LOG(LOG_ERR, "lseek err");
                }
                continue;
            }
            
            sscanf(nale_head, "len:%d,type:%d", &nalu_len, &nalu_type);
            /* 读取h264数据 */            
            read_len = read(h264data_fd, h264_frame_data_buf, nalu_len);
            if (read_len == 0)
            {
                curr_pos = lseek(h264data_fd, 0, SEEK_SET);
                if (curr_pos != 0)
                {
                    DBG_LOG(LOG_ERR, "lseek err");
                }
                continue;
            }
            else
            {
                /* 推流 */
                send_h264_frame_data(h264_frame_data_buf, nalu_len, nalu_type);
                video_push_cnt++;
            }
            
            live_delay(video_push_cnt, 25, 1);             //sleep 40ms
        }

    }
    return IPC_SUCCESS;
}


